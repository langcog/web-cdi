# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
"""
__author__ = 'Alisue <lambdalisue@hashnote.net>'
try:
    from django.test.utils import override_settings
except ImportError:
    from override_settings import override_settings
