def string_bool_coerce(val):
    return val in ['True','true','t','T']