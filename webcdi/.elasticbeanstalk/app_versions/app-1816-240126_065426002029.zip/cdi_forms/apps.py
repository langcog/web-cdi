from django.apps import AppConfig

class CatFormsConfig(AppConfig):
    name = 'cdi_forms'
