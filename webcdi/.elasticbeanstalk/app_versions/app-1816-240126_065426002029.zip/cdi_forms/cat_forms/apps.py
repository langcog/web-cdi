from django.apps import AppConfig

class CatFormsConfig(AppConfig):
    name = 'cat_forms'
