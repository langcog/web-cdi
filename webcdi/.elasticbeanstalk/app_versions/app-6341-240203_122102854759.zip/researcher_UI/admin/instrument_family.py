from django.contrib import admin
from researcher_UI.models import InstrumentFamily
admin.site.register(InstrumentFamily)