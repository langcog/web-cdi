# -*- coding: utf-8 -*-
from __future__ import unicode_literals
# This is for compatibility to django-registration
from registration.management.commands.cleanup_registrations import *
