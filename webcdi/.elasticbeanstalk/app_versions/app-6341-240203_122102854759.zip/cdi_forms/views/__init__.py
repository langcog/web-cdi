from .views import *  # noqa
from .pdf_detail_views import PDFAdministrationDetailView  # noqa
from .background_info_views import BackgroundInfoView, BackpageBackgroundInfoView, CreateBackgroundInfoView  # noqa
from .administration_views import AdministrationDetailView, AdministrationSummaryView, AdministrationUpdateView, update_administration_data_item  # noqa
from .instructions_views import InstructionDetailView  # noqa
from .contact_views import AdministrationContactView  # noqa